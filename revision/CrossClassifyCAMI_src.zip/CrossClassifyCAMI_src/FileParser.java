/*
 * CrossClassify is a tool for mapping results of metagenomic analyses from one taxonomy onto another.
 * Copyright (C) 2016 Monika Balvociute
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package taxonomies;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author monika
 */
public class FileParser 
{
    static InputStream IS;
    
    static Map<String,String> synonimsPhylum = new HashMap<>();
    static Map<String,String> synonimsClass = new HashMap<>();
    static Map<String,String> synonimsOrder = new HashMap<>();
    static Map<String,String> synonimsFamily = new HashMap<>();
    static Map<String,String> synonimsGenus = new HashMap<>();
    static Map<String,String> synonimsSpecies = new HashMap<>();
    
    static Map<String, ArrayList<Node>> allByName = new HashMap<>();

    static Node[] idMap = new Node[2000000];
    
    static ArrayList<Integer> list = null;
    
    static String nodesFile = "nodes.dmp";
    static String namesFile = "names.dmp";
    static String silvaFile = "silva.txt";
    
    
    static Node parseInput(String type, Boolean synonyms, Map<String, ArrayList<Node>> toMap) throws FileNotFoundException, IOException 
    {
        return parse(type, toMap, synonyms);
    }

    static Node parseReference(String type, Boolean synonyms, Map<String, ArrayList<Node>> ref) throws FileNotFoundException, IOException 
    {
        return parse(type, ref, synonyms);
    }

    static Node parse(String type,
            Map<String, ArrayList<Node>> map,
            Boolean synonyms) throws FileNotFoundException, IOException
    {
        switch (type)
        {
            case("ncbi"):
            {
                return parseNCBI(nodesFile, namesFile, map, synonyms);
            }
            case("silva"):
            {
                return parseSILVA(silvaFile, map);
            }
            default:
                return null;
        }
    }

    public static Node parseNCBI(String nodes, String names, 
            Map<String, ArrayList<Node>> map, boolean createDictionary) throws FileNotFoundException, IOException 
    {
        ArrayList<String>[] nodeNames = null;
        String[] scNames = null;
        
        if(createDictionary)
        {
            nodeNames = new ArrayList[2000000];
            scNames = new String[2000000];
        }
        
        Map<String, Integer> types = new HashMap<>();
        
        IS = new FileInputStream(nodes);
        
        int last = 0;
        
        byte[] b = new byte[IS.available()];
        byte[] leftOver = null;
        
        int lastRead = 0;
        
        while(IS.available() > 0)
        {
            if(last != 0)
            {
                leftOver = Arrays.copyOfRange(b, last, lastRead);
            }
            b = new byte[IS.available()];
            int read = IS.read(b);
            
            if(leftOver != null)
            {
                byte[] tmp = new byte[leftOver.length +  read];
                System.arraycopy(leftOver, 0, tmp, 0, leftOver.length);
                System.arraycopy(b, 0, tmp, leftOver.length, read);
                b = tmp;
                read = b.length;
            }
            
            lastRead = read;
            for(int i = 0; i < read; i++)
            {
                if(b[i] >= 65 && b[i] <= 90)
                {
                    b[i] += 32;
                }
                if(b[i] == 10) // new line
                {
                    int id = 0;
                    int pId = 0;
                    String rank = "";
                    int bars = 0;
                    boolean gap = false;
                    for(int j = last; j < i; j++)
                    {
                        if(b[j] == 124) // separator "|" found
                        {
                            bars++;
                        }
                        else
                        {
                            if(bars == 0 && b[j] >= 48 && b[j] <= 57) //Reading id
                            {
                                id = id*10 + b[j] - 48;
                            }
                            if(bars == 1 && b[j] >= 48 && b[j] <= 57) //Reading parent id
                            {
                                pId = pId*10 + b[j] - 48;
                            }
                            if(bars == 2 && b[j] >= 97 && b[j] <= 122)
                            {
                                if(gap)
                                {
                                    rank += " ";
                                    gap = false;
                                }
                                rank += (char) b[j];
                            }
                            if(bars == 2 && b[j] <= 32 && rank.length() > 0)
                            {
                                gap = true;
                            }
                            if(bars == 3)
                            {
                                addNodeNCBI(rank, types, id, pId);
                                break;
                            }
                        }
                    }
                    last = i;
                }
            }
        }
        IS.close();
        
        IS = new FileInputStream(names);
        last = 0;
        
        b = new byte[IS.available()];
        leftOver = null;
        
        lastRead = 0;
        
        while(IS.available() > 0)
        {
            if(last != 0)
            {
                leftOver = Arrays.copyOfRange(b, last, lastRead);
            }
            b = new byte[IS.available()];
            int read = IS.read(b);
            
            if(leftOver != null)
            {
                byte[] tmp = new byte[leftOver.length +  read];
                System.arraycopy(leftOver, 0, tmp, 0, leftOver.length);
                System.arraycopy(b, 0, tmp, leftOver.length, read);
                b = tmp;
                read = b.length;
            }
            
            lastRead = read;
            for(int i = 0; i < read; i++)
            {
                if(b[i] >= 65 && b[i] <= 90)
                {
                    b[i] += 32;
                }
                if(b[i] == 10) // new line
                {
                    int id = 0;
                    String name = "";
                    String nameType = "";
                    int bars = 0;
                    boolean gap = false;
                    for(int j = last; j < i; j++)
                    {
                        if(b[j] == 124) // separator "|" found
                        {
                            bars++;
                        }
                        else
                        {
                            if(bars == 0 && b[j] >= 48 && b[j] <= 57) //Reading id
                            {
                                id = id*10 + (b[j] - 48);
                            }
                            if(bars == 1 && b[j] > 32)
                            {
                                //if(b[j] != 34 && b[j] != 91 && b[j] != 93 )
                                if(b[j] != 34 && b[j] != 39 && b[j] != 91 && b[j] != 93 )
                                {
                                    if(gap && name.length() > 0)
                                    {
                                        name += " ";
                                    }
                                    gap = false;
                                    name += (char) b[j];
                                }
                            }
                            if(bars == 3 && b[j] > 32)
                            {
                                if(b[j] != 34 && b[j] != 39 && b[j] != 91 && b[j] != 93 )
                                {
                                    if(gap && nameType.length() > 0)
                                    {
                                        nameType += " ";
                                    }
                                    gap = false;
                                    nameType += (char) b[j];
                                }
                            }
                            if(b[j] <= 32)
                            {
                                gap = true;
                            }
                        }
                        
                    }
                    assignNameToNode(nameType, id, name, map, scNames, 
                            nodeNames, list, createDictionary);
                    last = i;
                }
            }
        }
        IS.close();
        
        if(createDictionary)
        {
            makeSynonimDictionary(scNames, nodeNames);
        }
        
        Node root = idMap[1];
        
        if(map != null) //making sure that root rank is "named" in the same way
        {
            String rootKey = root.generateKey();
            ArrayList<Node> rootList = map.remove(rootKey);
            root.type = "root";
            root.name = "root";   
            map.put(root.generateKey(), rootList);
        }
        else
        {
            root.type = "root";
            root.name = "root";     
        }
        
        return root;        
    }
    
    //Parses NCBI names file to create a synonim dictionary
    protected static void parseNCBISynonimsOnly() throws FileNotFoundException, IOException 
    {
        parseNCBI(nodesFile, namesFile, null, true);
    }
    
    private static void addNodeNCBI(String rank, Map<String, Integer> types, int id, int pId) 
    {
        if(rank.contentEquals("superkingdom"))
        {
            rank = "domain";
        }
        
        int no = 1;
        if(types.containsKey(rank))
        {
            no += types.get(rank);
        }
        types.put(rank, no);
        
        Node node = new Node(id, pId, rank, "NCBI");
        idMap[id] =  node;
    }
    
    private static void makeSynonimDictionary(String[] scNames, ArrayList<String>[] nodeNames)
    {
        for(int id = 0; id < scNames.length; id++)
        {
            String scName = scNames[id];
            if(scName != null)
            {
                String type = idMap[id].type;

                putToSynonims(type, scName, scName);
                ArrayList<String> syn = nodeNames[id];
                if(syn != null)
                {
                    for(String s : syn)
                    {
                        putToSynonims(type, s, scName);
                    }
                }
            }
        }
    }
    
    private static void putToSynonims(String type, String name, String sc) 
    {
        switch (type) 
        {
            case "phylum":
                synonimsPhylum.put(name, sc);
                break;
            case "class":
                synonimsClass.put(name, sc);
                break;
            case "order":
                synonimsOrder.put(name, sc);
                break;
            case "family":
                synonimsFamily.put(name, sc);
                break;
            case "genus":
                synonimsGenus.put(name, sc);
                break;
            case "species":
                synonimsSpecies.put(name, sc);
                break;
        }
    }
    
    private static void assignNameToNode(String nameType, int id, String name, 
            Map<String, ArrayList<Node>> map, String[] scNames,
            ArrayList<String>[] nodeNames, ArrayList<Integer> list,
            boolean createDictionary) 
    {
        if(nameType.equals("scientific name"))
        {
            Node node = idMap[id];
            node.name = name;
            node.nameOriginal = name;
            
            if((list != null && list.contains(id) )|| list == null)
            {
                addToNameSet(map, node);
            }
            if(createDictionary)
            {
                scNames[id] = name;
            }
            
            
            ArrayList<Node> thisName = allByName.get(name);
            if(thisName == null)
            {
                thisName = new ArrayList<>();
            }
            thisName.add(node);
            allByName.put(name, thisName);
            
            if(node.id != node.parentId)
            {
                Node parent = idMap[node.parentId];
                node.parent = parent;
                parent.putChild(node.name, node);
            }
        }
        else if(createDictionary)
        {
            if(nodeNames[id] == null)
            {
                nodeNames[id] = new ArrayList<>();
            }
            nodeNames[id].add(name);
        }
    }

    private static Node parseSILVA(String file, Map<String, ArrayList<Node>> map) throws FileNotFoundException, IOException 
    {
        Node start = new Node("root", "root", "Silva");
        addToNameSet(map, start);
        start.nameOriginal = "SILVA";
        start.id = 1;
        
        IS = new FileInputStream(file);
        int last = 0;
        
        byte[] b = new byte[IS.available()];
        byte[] leftOver = null;
        
        int lastRead = 0;
        
        int genus = 0;
        
        HashMap<String,Integer> rankss = new HashMap<>();
        
        while(IS.available() > 0)
        {
            if(last != 0)
            {
                leftOver = Arrays.copyOfRange(b, last, lastRead);
            }
            b = new byte[IS.available()];
            int read = IS.read(b);
            
            if(leftOver != null)
            {
                byte[] tmp = new byte[leftOver.length +  read];
                System.arraycopy(leftOver, 0, tmp, 0, leftOver.length);
                System.arraycopy(b, 0, tmp, leftOver.length, read);
                b = tmp;
                read = b.length;
            }
            
            lastRead = read;
            for(int i = 0; i < read; i++)
            {
                if(b[i] == 10) // new line
                {
                    int id = 0;
                    String[] el = new String[20];
                    int index = 0;
                    String name = "";
                    String rank = "";
                    int bars = 0;
                    boolean gap = false;
                    for(int j = last; j < i; j++)
                    {
                        if(b[j] == 9) // separator "tab" found
                        {
                            bars++;
                            while(b[j+1] == 9)
                            {
                                j++;
                            }
                        }
                        else
                        {
                            if(bars == 0) //Reading path
                            {
                                if(b[j] == 59) //separator ";"
                                {
                                    el[index++] = name;
                                    
                                    name = "";
                                }
                                else if(b[j] > 32 && b[j] != 34 && b[j] != 39 && b[j] != 91 && b[j] != 93 )
                                {
                                    if(gap && name.length() > 0)
                                    {
                                        name += " ";
                                    }
                                    gap = false;
                                    name += (char) b[j];
                                }
                            }
                            if(bars == 2) // Reading rank
                            {
                                if(b[j] > 32 && b[j] != 34 && b[j] != 39 && b[j] != 91 && b[j] != 93 )
                                {
                                    if(gap && rank.length() > 0)
                                    {
                                        rank += " ";
                                    }
                                    gap = false;
                                    rank += (char) b[j];
                                    
                                }
                            }
                            if(bars == 1 && b[j] >= 48 && b[j] <= 57) //Reading id
                            {
                                id = id*10 + (b[j] - 48);
                            }
                            if(b[j] <= 32)
                            {
                                gap = true;
                            }
                        }
                    }
                    
                    Node previous = start;
                    
                    for (int k = 0; k < el.length; k++) 
                    {
                        if(el[k] == null)
                        {
                            break;
                        }
                       // System.out.print(l[k] + "-");
                        String nam = el[k];
                        name = nam.toLowerCase();
                        //name = getScName(name, rank);
                        Node n = previous.children.get(name);
                        if (n == null) 
                        {
                            if(el[k+1] == null)
                            {
                                n = new Node(name, rank, "Silva");
                                addToNameSet(map, n);
                            }
                            else
                            {
                                n = new Node(name, "", "Silva");
                            }
                            
                            n.nameOriginal = nam;
                            n.id = id;
                            
                            
                            previous.putChild(n.name, n);
                            n.parent = previous;
                            
                        }
                        previous = n;
                    }
                    last = i;
                }
            }
        }
        IS.close();
        
        
        
        start.type = "root";
        start.name = "root";
        return  start;   
    }
    
    private static String getScName(String name, String type)
    {
        Map<String, String> synonims = getSynMap(type);
        if(synonims != null)
        {
            if(synonims.containsKey(name))
            {
                return synonims.get(name);
            }

            String extendedName = "uncultured candidate division " + name + " bacterium";
            if(synonims.containsKey(extendedName))
            {
                return synonims.get(extendedName);
            }
            if(name.contains("uncultured candidate division ") && name.contains(" bacterium"))
            {
                String sName = name;
                sName = sName.replace("uncultured candidate division ", "");
                sName = sName.replace(" bacterium", "");
                if(synonims.containsKey(sName))
                {
                    return synonims.get(sName);
                }
            }
            extendedName = "candidate division " + name;
            if(synonims.containsKey(extendedName))
            {
                return synonims.get(extendedName);
            }
            if(name.contains("candidate division "))
            {
                String sName = name;
                sName = sName.replace("candidate division ", "");
                if(synonims.containsKey(sName))
                {
                    return synonims.get(sName);
                }
            }

            extendedName = "uncultured " + name + " bacterium";
            if(synonims.containsKey(extendedName))
            {
                return synonims.get(extendedName);
            }
            if(name.contains("uncultured ") && name.contains(" bacterium"))
            {
                String sName = name;
                sName = sName.replace("uncultured ", "");
                sName = sName.replace(" bacterium", "");
                if(synonims.containsKey(sName))
                {
                    return synonims.get(sName);
                }
            }
        }
            
        return name;
    }

    private static Map<String, String> getSynMap(String type) 
    {
        switch(type)
        {
            case "phylum":
                return synonimsPhylum;
            case "class":
                return synonimsClass;
            case "order":
                return synonimsOrder;
            case "family":
                return synonimsFamily;
            case "genus":
                return synonimsGenus;
            case "species":
                return synonimsSpecies;
                        
        }
        return null;
    }
    
    private static void addToNameSet(Map<String, ArrayList<Node>> map, Node n)
    {
        if(map != null)
        {
            ArrayList<Node> sameName = map.get(n.name + "-" + n.type);
            if(sameName == null)
            {
                sameName = new ArrayList<>();
            }
            sameName.add(n);
            map.put(n.name + "-" + n.type, sameName);
        }
    }

}