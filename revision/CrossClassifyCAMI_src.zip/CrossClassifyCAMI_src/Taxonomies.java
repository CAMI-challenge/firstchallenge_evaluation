/*
 * CrossClassify is a tool for mapping results of metagenomic analyses from one taxonomy onto another.
 * Copyright (C) 2016 Monika Balvociute
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package taxonomies;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author monika
 */
public class Taxonomies 
{
    /**
     * @param args the command line arguments
     */
    
    
    static Node treeToMap = null;
    
    static Map<String,ArrayList<Node>> ref;
    static Node refTree = null;
    
    static Info info = new Info();
    
    static String refTax = "silva";
    static Boolean synonims = true;
    static Boolean strict = false;
    
    static String inTax = "ncbi";
    
    public static void main(String[] args) throws Exception 
    {
        if(args.length > 0 && args[0].toLowerCase().contentEquals("-s"))
        {
            strict = true;
        }
        
        inTax = "ncbi";
        refTax = "silva";
                
        parseFiles(strict);
        
        removeIntermediateNodes();
        if(strict)
        {
            Mapper.mapStrict(treeToMap, refTree);
        }
        else
        {
            Mapper.mapLoose(treeToMap, ref);
        }

        evaluateMapping();
    }
    
    private static void removeIntermediateNodes() 
    {
        Mapper.removeIntermediate(null, treeToMap);
        Mapper.removeIntermediate(ref, refTree);
    }

    private static boolean evaluateMapping() throws IOException 
    {
        Evaluator ev = new Evaluator();
        int n = 598;
        String[] rank = new String[n];
        String[] name = new String[n];
        String[] line = new String[n];
        String header = null;
        boolean evFile = false;
        try
        {
            header = readEvFile(rank, name, line);
            evFile = true;
        }
        catch(IOException ioe)
        {
            
        }
        ev.makeStats(treeToMap, refTree);
        String mappingType = (strict) ? "str" : "loose";
        ev.printNodeStats(treeToMap, refTree, rank, name, line, evFile, header, mappingType);
        return false;
    }


    private static void parseFiles(boolean makeMap) throws Exception 
    {
        boolean parsed = false;
        if(makeMap)
        {
            ref = new HashMap<>();
        }
        ref = new HashMap<>();
        if (synonims) 
        {
            if (refTax.contentEquals("ncbi")) 
            {
                parseReference();
                parseInput();
                parsed = true;
            } 
            else if (!inTax.contentEquals("ncbi")) 
            {
                parseSynonims();
            }
        }
        if (!parsed) 
        {
            parseInput();
            parseReference();
        }
    }
  
    private static void parseSynonims() throws Exception 
    {
        try 
        {
            FileParser.parseNCBISynonimsOnly();
        } 
        catch (IOException ex) 
        {
            throw new Exception("Error occured while parsing names file.");
        }
    }

    private static void parseReference() throws Exception 
    {
        try 
        {
            refTree = FileParser.parseReference(refTax, synonims, ref);
        } 
        catch (IOException ex) 
        {
            ex.printStackTrace();
            throw new Exception("Error occured while parsing reference taxonomy.");
        }
    }

    private static void parseInput() throws Exception 
    {
        try 
        {
            treeToMap = FileParser.parseInput(inTax, synonims, null);
        } 
        catch (IOException ex) 
        {
           ex.printStackTrace();
           throw new Exception("Error occured while parsing input taxonomy.");
        }
    }
    
    private static String readEvFile(String[] rank, String[] name, String[] line) throws FileNotFoundException, IOException 
    {
        String file = "per_taxon_sorted.tsv";
        BufferedReader br = new BufferedReader(new FileReader(file));
        String ln = br.readLine();
        String header = ln.trim();
        ln = br.readLine();
        int i = 0;
        while(ln != null)
        {
            ln = ln.trim();
            String[] el = ln.split("\\t");
            rank[i] = el[0];
            name[i] = el[1];
            line[i] = ln;
            if(rank[i].contentEquals("superkingdom"))
            {
                rank[i] = "domain";
            }
            name[i] = name[i].replaceAll("\\[", "");
            name[i] = name[i].replaceAll("\\]", "");
            i++;
            ln = br.readLine();
        }
        br.close();
        return header;
    }
    
}
