/*
 * CrossClassify is a tool for mapping results of metagenomic analyses from one taxonomy onto another.
 * Copyright (C) 2016 Monika Balvociute
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package taxonomies;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;


/**
 *
 * @author monika
 */
public class Evaluator 
{
    
    
    public Evaluator() 
    {
    }
    
    public void makeStats(Node treeToMap, Node refTree) throws IOException
    {

        int[][] mapped = new int[8][8];
        int[][] refMap = new int[8][8];

        ArrayList<Node> nodesToMap = new ArrayList<>();
        
        nodesToMap.add(treeToMap);

        while(!nodesToMap.isEmpty())
        {
            Node n = nodesToMap.remove(0);
            
            nodesToMap.addAll(n.children.values());

            Node m = n.getM();

            int mtype = getClosestType(m);
            int ntype = getClosestType(n);

            n.mappedTo = ntype - mtype;
            n.rank = ntype;
            m.rank = mtype;
            
            int cntype = ntype == 7 ? 6 : ntype;
            int cmtype = mtype == 7 ? 6 : mtype;

            n.mappedToScore = cntype - cmtype;
            n.rankScore = cntype;

            mapped[ntype][mtype]++;
            if(!m.mapped[ntype])
            {
                refMap[mtype][ntype]++;
                m.mapped[ntype] = true;
            }
        }
    }
    
    private int getClosestType(Node n)
    {
        int type = 0;
        String rank = n.type;
        if(rank.startsWith("sub"))
        {
            rank = rank.substring(3);
        }
        else if(rank.startsWith("super") || rank.startsWith("infra"))
        {
            rank = rank.substring(5);
        }
        if(n.type != null && Info.hi.containsKey(rank))
        {
            type =  Info.hi.get(rank);
        }
        else
        {
            LinkedList<Node> nPath = n.getPath();
            while(!nPath.isEmpty())
            {
                Node nn = nPath.removeLast();
                
                rank = nn.type;
                if(rank.startsWith("sub"))
                {
                    rank = rank.substring(3);
                }
                else if(rank.startsWith("super") || rank.startsWith("infra"))
                {
                    rank = rank.substring(5);
                }
                
                if(nn.type != null && Info.hi.containsKey(rank))
                {
                    type =  Info.hi.get(rank);
                    break;
                }
            }
        }
        return type;
    }
    
    static double power(double d, int p)
    {
        double r;
        if(p == 0)
        {
            r = 0.0;
        }
        else
        {
            r = 1.0;
            for (int i = 0; i < p; i++) 
            {
                r *= d;
            }
        }
        return r;
    }
    
    void printNodeStats(Node treeToMap, Node refTree, 
            String[] rank, String[] name, String[] line, 
            boolean evFile, String header, String mappinType) 
    {

        String[] output = new String[rank.length];
        ArrayList<Node> nodesToMap = new ArrayList<>();
        nodesToMap.add(treeToMap);
        if(!evFile)
        {
             System.out.println("rank_" + treeToMap.source + "\t" + 
                            "taxon_" + treeToMap.source + "\t" + 
                            "rank_diff_" + mappinType + "\t" + 
                            "surroundings_" + mappinType  + "\t" + 
                            "rank_" + refTree.source + "_" + mappinType + "\t" + 
                            "taxon_" + refTree.source + "_" + mappinType);
        }
        else
        {
            System.out.println(header + "\t" + 
                    "rank_diff_" + mappinType + "\t" + 
                    "surroundings_"+ mappinType + "\t" + 
                    "rank_" + refTree.source +"_" + mappinType+ "\t" 
                    + "taxon_" + refTree.source +"_" + mappinType);
        }
        while(!nodesToMap.isEmpty())
        {
            Node n = nodesToMap.remove(0);  
            nodesToMap.addAll(n.children.values());
            Node m = n.m;

            if(!evFile)
            {
                double score = getEnvScore(n);
                System.out.println(n.type + "\t" + 
                        n.nameOriginal + "\t" + 
                        n.mappedToScore + "\t" + 
                        score  + "\t" + 
                        m.type + "\t" + m.nameOriginal);
            }
            else
            {
                int ind = getIndex(n, rank, name);

                if(ind != -1)
                {
                    double score = getEnvScore(n);

                    String out = n.mappedToScore + "\t" + score + "\t" + m.type + "\t" + m.nameOriginal;
                    output[ind] = out;
                } 
            }
        }
        if(evFile)
        {
            for (int i = 0; i < line.length; i++) 
            {
                System.out.println(line[i] + "\t" + output[i]);
            }
        }
    }

    private int getIndex(Node n, String[] rank, String[] name) 
    {
        int i = -1;
        for (int j = 0; j < rank.length; j++) 
        {
            if(name[j].toLowerCase().contentEquals(n.nameOriginal.toLowerCase()) && 
                    rank[j].toLowerCase().contentEquals(n.type.toLowerCase()))
            {
                i = j;
            }
        }
        return i;
    }
    
    private double getEnvScore(Node n) 
    {
        double score = 0.0;
        double sum = 0.0;
        
        Node parent;
        if(n.parent == null)
        {
            parent = n;
        }
        else
        {
            parent = n.parent;
        }
        
        ArrayList<Node> nodesToMap = new ArrayList<>();
        
        nodesToMap.add(parent);
        nodesToMap.addAll(parent.children.values());
        
        for(Node x : parent.children.values())
        {
            if(x.children != null && !x.children.isEmpty())
            {
                nodesToMap.addAll(x.children.values());
                for(Node xx : x.children.values())
                {
                    if(xx.children != null && xx.children.isEmpty())
                    {
                        nodesToMap.addAll(xx.children.values());
                    }
                }
            }
        }

        
        while(!nodesToMap.isEmpty())
        {
            n = nodesToMap.remove(0);  
            
            score += (double)n.mappedToScore;
            sum += (double)n.rankScore;
        }
        
        
        return score/sum;
    }
    
}


